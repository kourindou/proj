import pickle

a=100.01

with open('res/Highscore.pickle','wb') as f:
    pickle.dump(a,f)




